```python
#1. Data Pipeline Creation
```


```python
#1.1 Import Data
```


```python
import numpy as np, tensorflow as tf, cv2 
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import os
import keras
import imghdr
from matplotlib import pyplot as plt
```


```python
os.path.join('Desktop/Code/AI/Final Run Brain Tumor CNN/Dataset')
```




    'Desktop/Code/AI/Final Run Brain Tumor CNN/Dataset'




```python
#1.2 GPU Setup
```


```python
gpus = tf.config.experimental.list_physical_devices('GPU')
len(gpus)
```




    1




```python
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)
```


```python
#1.3 Remove Dodgy Images
```


```python
data_dir1 = r'C:\Users\USER\Desktop\Code\AI\Final Run Brain Tumor CNN\Dataset\Testing'
data_dir2 = r'C:\Users\USER\Desktop\Code\AI\Final Run Brain Tumor CNN\Dataset\Training'
image_exts = ['jpeg', 'jpg', 'bmp', 'png']
```


```python
for image_class in os.listdir(data_dir1):
    for image in os.listdir(os.path.join(data_dir1, image_class)):
        image_path = os.path.join(data_dir1, image_class, image)
        try:
            img = cv2.imread(image_path)
            tip = imghdr.what(image_path)
            if tip not in image_exts:
                print("Image not in ext list {}".format(image_path))
                os.remove(image_path)
        except Exception as e:
            print('Issue with {Image}'.format(image_path))
```


```python
for image_class in os.listdir(data_dir2):
    for image in os.listdir(os.path.join(data_dir2, image_class)):
        image_path = os.path.join(data_dir2, image_class, image)
        try:
            img = cv2.imread(image_path)
            tip = imghdr.what(image_path)
            if tip not in image_exts:
                print("Image not in ext list {}".format(image_path))
                os.remove(image_path)
        except Exception as e:
            print('Issue with {Image}'.format(image_path))
```


```python
#2. Preprocessing Images for DL
```


```python
#2.1 Resizing + Labelling Data Set Categorically
```


```python
#Preprocessing Training Data Set:
X_train = []
Y_train = []
image_size = 150
labels = ['glioma_tumor', 'meningioma_tumor', 'no_tumor', 'pituitary_tumor']
for i in labels:
    folderpath = os.path.join(r'C:\Users\USER\Desktop\Code\AI\Final Run Brain Tumor CNN\Dataset\Training', i)
    for j in os.listdir(folderpath):
        img = cv2.imread(os.path.join(folderpath, j))
        img = cv2.resize(img, (image_size, image_size))
        X_train.append(img)
        Y_train.append(i)
        
#Preprocessing Testing Data Set:
X_test = []
Y_test = []
image_size = 150
labels = ['glioma_tumor', 'meningioma_tumor', 'no_tumor', 'pituitary_tumor']
for i in labels:
    folderpath = os.path.join(r'C:\Users\USER\Desktop\Code\AI\Final Run Brain Tumor CNN\Dataset\Testing', i)
    for j in os.listdir(folderpath):
        img = cv2.imread(os.path.join(folderpath, j))
        img = cv2.resize(img, (image_size, image_size))
        X_train.append(img)
        Y_train.append(i)

X_train = np.array(X_train)
Y_train = np.array(Y_train)
```


```python
#2.2 Shuffling Data
```


```python
X_train, Y_train = shuffle(X_train, Y_train, random_state = 101)
```


```python
#2.3: Train Test Split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_train, Y_train, test_size = 0.1, random_state = 101) 
```


```python
y_train_new = []
for i in y_train:
    y_train_new.append(labels.index(i))
y_train = y_train_new
y_train = tf.keras.utils.to_categorical(y_train)

y_test_new = []
for i in y_test:
    y_test_new.append(labels.index(i))
y_test = y_test_new
y_test = tf.keras.utils.to_categorical(y_test)
```


```python
#3 Creating Deep Neural Network
```


```python
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
```


```python
model = Sequential()
model.add(Conv2D(32, (3,3), activation = 'relu', input_shape = (150,150, 3)))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(256, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Flatten())
model.add(Dense(512, activation = 'relu'))
model.add(Dropout(0.3))
model.add(Dense(4, activation = 'softmax'))
```


```python
model.summary()
```

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     conv2d (Conv2D)             (None, 148, 148, 32)      896       
                                                                     
     conv2d_1 (Conv2D)           (None, 146, 146, 64)      18496     
                                                                     
     max_pooling2d (MaxPooling2D  (None, 73, 73, 64)       0         
     )                                                               
                                                                     
     dropout (Dropout)           (None, 73, 73, 64)        0         
                                                                     
     conv2d_2 (Conv2D)           (None, 71, 71, 64)        36928     
                                                                     
     conv2d_3 (Conv2D)           (None, 69, 69, 64)        36928     
                                                                     
     max_pooling2d_1 (MaxPooling  (None, 34, 34, 64)       0         
     2D)                                                             
                                                                     
     dropout_1 (Dropout)         (None, 34, 34, 64)        0         
                                                                     
     conv2d_4 (Conv2D)           (None, 32, 32, 128)       73856     
                                                                     
     conv2d_5 (Conv2D)           (None, 30, 30, 128)       147584    
                                                                     
     max_pooling2d_2 (MaxPooling  (None, 15, 15, 128)      0         
     2D)                                                             
                                                                     
     dropout_2 (Dropout)         (None, 15, 15, 128)       0         
                                                                     
     conv2d_6 (Conv2D)           (None, 13, 13, 128)       147584    
                                                                     
     conv2d_7 (Conv2D)           (None, 11, 11, 256)       295168    
                                                                     
     max_pooling2d_3 (MaxPooling  (None, 5, 5, 256)        0         
     2D)                                                             
                                                                     
     dropout_3 (Dropout)         (None, 5, 5, 256)         0         
                                                                     
     flatten (Flatten)           (None, 6400)              0         
                                                                     
     dense (Dense)               (None, 512)               3277312   
                                                                     
     dropout_4 (Dropout)         (None, 512)               0         
                                                                     
     dense_1 (Dense)             (None, 4)                 2052      
                                                                     
    =================================================================
    Total params: 4,036,804
    Trainable params: 4,036,804
    Non-trainable params: 0
    _________________________________________________________________
    


```python
def f1_score(y_true, y_pred):
    # Convert predictions to binary (0 or 1)
    y_pred = tf.round(y_pred)  # Round predictions to the nearest integer (0 or 1)
    
    # Calculate true positives, false positives, and false negatives
    true_positives = tf.reduce_sum(y_true * y_pred)
    predicted_positives = tf.reduce_sum(y_pred)
    actual_positives = tf.reduce_sum(y_true)

    # Calculate precision and recall
    precision = true_positives / (predicted_positives + tf.keras.backend.epsilon())
    recall = true_positives / (actual_positives + tf.keras.backend.epsilon())

    # Calculate F1 score
    f1 = 2 * (precision * recall) / (precision + recall + tf.keras.backend.epsilon())
    return f1
```


```python
model.compile(loss = 'categorical_crossentropy', optimizer = 'Adam', metrics=['accuracy', f1_score, keras.metrics.Precision(), keras.metrics.Recall()])
```


```python
#3.2 Train
```


```python
history = model.fit(X_train, y_train, epochs = 30, validation_split = 0.1)
```

    Epoch 1/30
    83/83 [==============================] - 10s 75ms/step - loss: 3.1426 - accuracy: 0.2853 - f1_score: 0.0132 - precision: 0.1719 - recall: 0.0125 - val_loss: 1.3682 - val_accuracy: 0.2891 - val_f1_score: 0.0000e+00 - val_precision: 0.0000e+00 - val_recall: 0.0000e+00
    Epoch 2/30
    83/83 [==============================] - 5s 57ms/step - loss: 1.3315 - accuracy: 0.3477 - f1_score: 0.0160 - precision: 0.4355 - recall: 0.0102 - val_loss: 1.2289 - val_accuracy: 0.4286 - val_f1_score: 0.1641 - val_precision: 0.6923 - val_recall: 0.0918
    Epoch 3/30
    83/83 [==============================] - 5s 59ms/step - loss: 1.1596 - accuracy: 0.4858 - f1_score: 0.2631 - precision: 0.5668 - recall: 0.1846 - val_loss: 1.1360 - val_accuracy: 0.5034 - val_f1_score: 0.4392 - val_precision: 0.5926 - val_recall: 0.3810
    Epoch 4/30
    83/83 [==============================] - 5s 56ms/step - loss: 0.9758 - accuracy: 0.5808 - f1_score: 0.5075 - precision: 0.6724 - recall: 0.4124 - val_loss: 0.9552 - val_accuracy: 0.5748 - val_f1_score: 0.4853 - val_precision: 0.7161 - val_recall: 0.3776
    Epoch 5/30
    83/83 [==============================] - 5s 56ms/step - loss: 0.9097 - accuracy: 0.6213 - f1_score: 0.5613 - precision: 0.6930 - recall: 0.4748 - val_loss: 0.9285 - val_accuracy: 0.5850 - val_f1_score: 0.5502 - val_precision: 0.6555 - val_recall: 0.5306
    Epoch 6/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.8011 - accuracy: 0.6716 - f1_score: 0.6406 - precision: 0.7374 - recall: 0.5683 - val_loss: 0.7516 - val_accuracy: 0.6463 - val_f1_score: 0.6191 - val_precision: 0.7500 - val_recall: 0.5612
    Epoch 7/30
    83/83 [==============================] - 5s 57ms/step - loss: 0.7083 - accuracy: 0.7185 - f1_score: 0.6930 - precision: 0.7668 - recall: 0.6334 - val_loss: 0.7876 - val_accuracy: 0.6565 - val_f1_score: 0.6265 - val_precision: 0.7300 - val_recall: 0.5884
    Epoch 8/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.6665 - accuracy: 0.7378 - f1_score: 0.7177 - precision: 0.7809 - recall: 0.6663 - val_loss: 0.6732 - val_accuracy: 0.7007 - val_f1_score: 0.6458 - val_precision: 0.7500 - val_recall: 0.6122
    Epoch 9/30
    83/83 [==============================] - 5s 56ms/step - loss: 0.6021 - accuracy: 0.7613 - f1_score: 0.7502 - precision: 0.8026 - recall: 0.7060 - val_loss: 0.7512 - val_accuracy: 0.6871 - val_f1_score: 0.6626 - val_precision: 0.7186 - val_recall: 0.6429
    Epoch 10/30
    83/83 [==============================] - 5s 57ms/step - loss: 0.5255 - accuracy: 0.7896 - f1_score: 0.7909 - precision: 0.8317 - recall: 0.7552 - val_loss: 0.5037 - val_accuracy: 0.7687 - val_f1_score: 0.7530 - val_precision: 0.8044 - val_recall: 0.7415
    Epoch 11/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.4377 - accuracy: 0.8305 - f1_score: 0.8263 - precision: 0.8577 - recall: 0.7983 - val_loss: 0.4707 - val_accuracy: 0.8061 - val_f1_score: 0.8111 - val_precision: 0.8262 - val_recall: 0.7925
    Epoch 12/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.3977 - accuracy: 0.8441 - f1_score: 0.8417 - precision: 0.8683 - recall: 0.8180 - val_loss: 0.4227 - val_accuracy: 0.8503 - val_f1_score: 0.8395 - val_precision: 0.8582 - val_recall: 0.8231
    Epoch 13/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.3645 - accuracy: 0.8680 - f1_score: 0.8635 - precision: 0.8878 - recall: 0.8415 - val_loss: 0.4132 - val_accuracy: 0.8367 - val_f1_score: 0.8143 - val_precision: 0.8551 - val_recall: 0.8027
    Epoch 14/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.3465 - accuracy: 0.8763 - f1_score: 0.8742 - precision: 0.8962 - recall: 0.8555 - val_loss: 0.4748 - val_accuracy: 0.8129 - val_f1_score: 0.8018 - val_precision: 0.8252 - val_recall: 0.8027
    Epoch 15/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.3233 - accuracy: 0.8857 - f1_score: 0.8855 - precision: 0.9006 - recall: 0.8710 - val_loss: 0.3962 - val_accuracy: 0.8401 - val_f1_score: 0.8571 - val_precision: 0.8648 - val_recall: 0.8265
    Epoch 16/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.2680 - accuracy: 0.8952 - f1_score: 0.8961 - precision: 0.9103 - recall: 0.8831 - val_loss: 0.3213 - val_accuracy: 0.8946 - val_f1_score: 0.8883 - val_precision: 0.9028 - val_recall: 0.8844
    Epoch 17/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.2515 - accuracy: 0.9111 - f1_score: 0.9092 - precision: 0.9195 - recall: 0.8994 - val_loss: 0.4372 - val_accuracy: 0.8776 - val_f1_score: 0.8700 - val_precision: 0.8793 - val_recall: 0.8673
    Epoch 18/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.2518 - accuracy: 0.9081 - f1_score: 0.9070 - precision: 0.9169 - recall: 0.8975 - val_loss: 0.3490 - val_accuracy: 0.8741 - val_f1_score: 0.8869 - val_precision: 0.8940 - val_recall: 0.8605
    Epoch 19/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.2412 - accuracy: 0.9081 - f1_score: 0.9081 - precision: 0.9174 - recall: 0.8990 - val_loss: 0.2881 - val_accuracy: 0.9048 - val_f1_score: 0.9014 - val_precision: 0.9138 - val_recall: 0.9014
    Epoch 20/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.2284 - accuracy: 0.9126 - f1_score: 0.9134 - precision: 0.9232 - recall: 0.9050 - val_loss: 0.3021 - val_accuracy: 0.9048 - val_f1_score: 0.8999 - val_precision: 0.9107 - val_recall: 0.9014
    Epoch 21/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.1943 - accuracy: 0.9319 - f1_score: 0.9329 - precision: 0.9414 - recall: 0.9247 - val_loss: 0.3281 - val_accuracy: 0.9150 - val_f1_score: 0.9195 - val_precision: 0.9204 - val_recall: 0.9048
    Epoch 22/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.1676 - accuracy: 0.9406 - f1_score: 0.9392 - precision: 0.9463 - recall: 0.9327 - val_loss: 0.2872 - val_accuracy: 0.9150 - val_f1_score: 0.9276 - val_precision: 0.9276 - val_recall: 0.9150
    Epoch 23/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.1781 - accuracy: 0.9353 - f1_score: 0.9350 - precision: 0.9425 - recall: 0.9296 - val_loss: 0.3172 - val_accuracy: 0.9320 - val_f1_score: 0.9371 - val_precision: 0.9349 - val_recall: 0.9286
    Epoch 24/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.1609 - accuracy: 0.9398 - f1_score: 0.9410 - precision: 0.9461 - recall: 0.9357 - val_loss: 0.2513 - val_accuracy: 0.9286 - val_f1_score: 0.9340 - val_precision: 0.9315 - val_recall: 0.9252
    Epoch 25/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.1536 - accuracy: 0.9425 - f1_score: 0.9435 - precision: 0.9473 - recall: 0.9391 - val_loss: 0.2690 - val_accuracy: 0.9184 - val_f1_score: 0.9258 - val_precision: 0.9273 - val_recall: 0.9116
    Epoch 26/30
    83/83 [==============================] - 5s 59ms/step - loss: 0.1267 - accuracy: 0.9591 - f1_score: 0.9585 - precision: 0.9622 - recall: 0.9546 - val_loss: 0.2606 - val_accuracy: 0.9184 - val_f1_score: 0.9260 - val_precision: 0.9244 - val_recall: 0.9150
    Epoch 27/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.1281 - accuracy: 0.9538 - f1_score: 0.9545 - precision: 0.9567 - recall: 0.9519 - val_loss: 0.2743 - val_accuracy: 0.9116 - val_f1_score: 0.9213 - val_precision: 0.9207 - val_recall: 0.9082
    Epoch 28/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.1331 - accuracy: 0.9576 - f1_score: 0.9576 - precision: 0.9611 - recall: 0.9538 - val_loss: 0.2593 - val_accuracy: 0.9354 - val_f1_score: 0.9218 - val_precision: 0.9377 - val_recall: 0.9218
    Epoch 29/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.1130 - accuracy: 0.9607 - f1_score: 0.9604 - precision: 0.9641 - recall: 0.9565 - val_loss: 0.3011 - val_accuracy: 0.9150 - val_f1_score: 0.9155 - val_precision: 0.9308 - val_recall: 0.9150
    Epoch 30/30
    83/83 [==============================] - 5s 58ms/step - loss: 0.1236 - accuracy: 0.9591 - f1_score: 0.9606 - precision: 0.9631 - recall: 0.9580 - val_loss: 0.2864 - val_accuracy: 0.9184 - val_f1_score: 0.9129 - val_precision: 0.9215 - val_recall: 0.9184
    


```python
model.save('BrainTumorIdentificationCNN.h5')
```


```python
#4: Evaluating Model Performance
```


```python
#4.1 Accuracy, Precision, F1, Loss Graphs:
```


```python
acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
epochs = range(len(acc))
plt.figure()

plt.plot(epochs, acc, 'r', label = "Training Accuracy")
plt.plot(epochs, val_acc, 'b', label = "Validation Accuracy")
plt.legend(loc = 'upper left')
plt.show()
```


    
![png](output_30_0.png)
    



```python
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(len(acc))
plt.figure()

plt.plot(epochs, loss, 'r', label = "Training Loss")
plt.plot(epochs, val_loss, 'b', label = "Validation Loss")
plt.legend(loc = 'upper left')
plt.show()
```


    
![png](output_31_0.png)
    



```python
prec = history.history['precision']
val_prec = history.history['val_precision']
epochs = range(len(acc))
plt.figure()

plt.plot(epochs, prec, 'r', label = "Training Precision")
plt.plot(epochs, val_prec, 'b', label = "Validation Precision")
plt.legend(loc = 'upper left')
plt.show()
```


    
![png](output_32_0.png)
    



```python
f1 = history.history['f1_score']
val_f1 = history.history['val_f1_score']
epochs = range(len(acc))
plt.figure()

plt.plot(epochs, f1, 'r', label = "Training Precision")
plt.plot(epochs, val_f1, 'b', label = "Validation Precision")
plt.legend(loc = 'upper left')
plt.show()
```


    
![png](output_33_0.png)
    



```python
rec = history.history['recall']
val_rec = history.history['val_recall']
epochs = range(len(acc))
plt.figure()

plt.plot(epochs, rec, 'r', label = "Training Recall")
plt.plot(epochs, val_rec, 'b', label = "Validation Recall")
plt.legend(loc = 'upper left')
plt.show()
```


    
![png](output_34_0.png)
    



```python
#4.2: Evaluate
```


```python
loss, accuracy, precision, f1_score, recall = model.evaluate(X_test, y_test)
```

    11/11 [==============================] - 0s 42ms/step - loss: 0.2856 - accuracy: 0.9358 - f1_score: 0.9430 - precision: 0.9415 - recall: 0.9358
    

M1 OG

model = Sequential()
model.add(Conv2D(32, (3,3), activation = 'relu', input_shape = (150,150, 3)))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(Conv2D(64, (3,3), activation = 'relu'))
#model.add(Dropout(0.3))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(256, (3,3), activation = 'relu'))
#model.add(Conv2D(256, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Flatten())
model.add(Dense(512, activation = 'relu'))
model.add(Dense(512, activation = 'relu'))
model.add(Dropout(0.3))
model.add(Dense(4, activation = 'softmax'))

M2 Simplified

model = Sequential()
model.add(Conv2D(32, (3,3), activation = 'relu', input_shape = (150,150, 3)))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(Conv2D(64, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation = 'relu'))
model.add(Conv2D(256, (3,3), activation = 'relu'))
model.add(MaxPooling2D(2,2))
model.add(Dropout(0.3))
model.add(Flatten())
model.add(Dense(512, activation = 'relu'))
model.add(Dropout(0.3))
model.add(Dense(4, activation = 'softmax'))
